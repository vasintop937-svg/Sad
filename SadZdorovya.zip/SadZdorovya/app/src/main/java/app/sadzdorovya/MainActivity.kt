package app.sadzdorovya

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import app.sadzdorovya.ui.navigation.SadZdorovyaApp
import app.sadzdorovya.ui.theme.SadZdorovyaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SadZdorovyaTheme {
                SadZdorovyaApp()
            }
        }
    }
}
