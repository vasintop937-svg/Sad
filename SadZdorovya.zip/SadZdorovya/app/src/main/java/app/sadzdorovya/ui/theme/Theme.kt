package app.sadzdorovya.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Green40,
    onPrimary = Cream99,
    primaryContainer = Green90,
    onPrimaryContainer = Green10,
    secondary = Earth40,
    onSecondary = Cream99,
    secondaryContainer = Earth90,
    onSecondaryContainer = Earth10,
    background = Cream99,
    onBackground = Ink10,
    surface = Cream99,
    onSurface = Ink10,
    surfaceVariant = Cream90,
    onSurfaceVariant = Ink30,
    outline = Ink60,
    error = ErrorRed,
    errorContainer = ErrorContainer,
    onErrorContainer = OnErrorContainer,
)

private val DarkColors = darkColorScheme(
    primary = Green80,
    onPrimary = Green10,
    primaryContainer = Green40,
    onPrimaryContainer = Green90,
    secondary = Earth80,
    onSecondary = Earth10,
    secondaryContainer = Earth40,
    onSecondaryContainer = Earth90,
    background = DarkSurface,
    onBackground = Cream95,
    surface = DarkSurface,
    onSurface = Cream95,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Cream90,
)

@Composable
fun SadZdorovyaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
