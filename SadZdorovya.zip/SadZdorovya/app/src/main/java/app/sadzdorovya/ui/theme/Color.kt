package app.sadzdorovya.ui.theme

import androidx.compose.ui.graphics.Color

// Спокойная природная палитра: мягкие зелёные, кремовые и тёплые земляные оттенки.
val Green40 = Color(0xFF3B6B3F)
val Green80 = Color(0xFFA8D5A2)
val Green90 = Color(0xFFD0EBCB)
val Green10 = Color(0xFF0D2A12)

val Earth40 = Color(0xFF7A5A3A)
val Earth80 = Color(0xFFE2C4A0)
val Earth90 = Color(0xFFF4E3CE)
val Earth10 = Color(0xFF2B1B09)

val Cream99 = Color(0xFFFBF7EE)
val Cream95 = Color(0xFFF3EEDF)
val Cream90 = Color(0xFFE6E1D2)

val Ink10 = Color(0xFF1C1B16)
val Ink30 = Color(0xFF47463D)
val Ink60 = Color(0xFF79786C)

val ErrorRed = Color(0xFFB3261E)
val ErrorContainer = Color(0xFFF9DEDC)
val OnErrorContainer = Color(0xFF410E0B)

val DarkSurface = Color(0xFF14160F)
val DarkSurfaceVariant = Color(0xFF2A2D22)
