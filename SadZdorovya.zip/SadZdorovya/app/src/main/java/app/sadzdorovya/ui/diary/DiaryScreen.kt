package app.sadzdorovya.ui.diary

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import app.sadzdorovya.R
import app.sadzdorovya.ui.components.PlaceholderScreen

@Composable
fun DiaryScreen(modifier: Modifier = Modifier) {
    PlaceholderScreen(stringResource(R.string.nav_diary), modifier)
}
