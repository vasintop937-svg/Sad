package app.sadzdorovya.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.ui.graphics.vector.ImageVector
import app.sadzdorovya.R

object Routes {
    const val HOME = "home"
    const val GARDEN = "garden"
    const val DIARY = "diary"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"
}

/** Разделы нижней навигации. */
enum class TopLevelDestination(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
) {
    HOME(Routes.HOME, R.string.nav_home, Icons.Filled.Home),
    GARDEN(Routes.GARDEN, R.string.nav_garden, Icons.Filled.Favorite),
    DIARY(Routes.DIARY, R.string.nav_diary, Icons.AutoMirrored.Filled.List),
    REPORTS(Routes.REPORTS, R.string.nav_reports, Icons.Filled.DateRange),
}
