package app.sadzdorovya.ui.theme

import androidx.compose.ui.unit.dp

object Dimens {
    val ScreenPadding = 20.dp
    val Spacing = 16.dp
    val SpacingSmall = 8.dp

    /** Минимальная высота основных кнопок и областей нажатия. */
    val TouchTarget = 56.dp
}
